retail-outlet-custom-post-type
==============================

Wordpress Custom Post Type Plugin to make updating retail outlets easier!
